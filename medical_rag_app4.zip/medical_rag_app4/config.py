"""
config.py - Configuration settings
"""

# Folder containing JSON test results
RESULTS_FOLDER = "results"

# Enable debug output
DEBUG_MODE = False